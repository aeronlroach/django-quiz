from django.apps import AppConfig


class QuizzesConfig(AppConfig):
    name = 'quizzes'
